package com.manchesterclub.manchesterfootball.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import com.acclivousbyte.gobblecustomer.view.dialog.AlertMessageDialog
import com.google.android.gms.tasks.OnCompleteListener
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.dialog.BookPitchDialog
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import com.manchesterclub.manchesterfootball.models.LoginUserModel
import com.manchesterclub.manchesterfootball.utils.KeyboardUtils
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.fragment_post_pitch.*
import java.lang.reflect.Type
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

/**
 * A simple [Fragment] subclass.
 */
class PostPitchFragment : BaseFragment() , BookPitchDialog.ItemClickBook {

    private var nameOfPitch: String = ""
    private var locationName: String = ""
    private var typesOfPitches: String = ""
    private var changingRoom: String = ""
    private var onSiteParking: String = ""
    private var indoorTxt: String = ""
    private var floodLitTxt: String = ""

    lateinit var footballPitchModel: FootballPitchModel
    var isFlag = false

    companion object {
        val ALLOWED_CHARACTERS = "0123456789qwertyuiopasdfghjklzxcvbnm"

        fun newInstance(footballPitchModel: FootballPitchModel, flag: Boolean) =
            PostPitchFragment().apply {
                arguments = Bundle().apply {
                    putSerializable("usermodel", footballPitchModel)
                    putBoolean("isFlag", flag)

                }
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_post_pitch, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments.let {
            footballPitchModel = it?.getSerializable("usermodel") as FootballPitchModel
            isFlag = it.getBoolean("isFlag")
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        locaton_text.setText(ManchesterFootballConfig.myLocationCityName)

        ivBackScreen.setOnClickListener {
            activity?.onBackPressed()
        }

        var popUp: AlertMessageDialog? = null

        if (!isFlag) {

            name_of_pitch.isEnabled = true
            rb_astro_turf.isEnabled = true
            rb_grass_pitch.isEnabled = true
            rb_change_room_yes.isEnabled = true
            rb_change_room_no.isEnabled = true
            rb_site_parking_yes.isEnabled = true
            rb_site_parking_no.isEnabled = true
            rb_indoor_yes.isEnabled = true
            rb_indoor_no.isEnabled = true
            rb_floodlit_yes.isEnabled = true
            rb_floodlit_no.isEnabled = true

            tvSubmitForm.text = "UPLOAD"

            rg_select_pitch_type.setOnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = view.findViewById(checkedId)
                if (radio.id == R.id.rb_astro_turf) {
                    typesOfPitches = ManchesterFootballConfig.ASTRO_TURF_PITCH
                } else {
                    typesOfPitches = ManchesterFootballConfig.GRASS_PITCH
                }

            }

            rg_changing_room.setOnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = view.findViewById(checkedId)
                if (radio.id == R.id.rb_change_room_yes) {
                    changingRoom = ManchesterFootballConfig.SELECTED_YES
                } else {
                    changingRoom = ManchesterFootballConfig.SELECTED_NO
                }

            }

            rg_site_parking.setOnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = view.findViewById(checkedId)
                if (radio.id == R.id.rb_site_parking_yes) {
                    onSiteParking = ManchesterFootballConfig.SELECTED_YES
                } else {
                    onSiteParking = ManchesterFootballConfig.SELECTED_NO
                }

            }

            rg_indoor.setOnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = view.findViewById(checkedId)
                if (radio.id == R.id.rb_indoor_yes) {
                    indoorTxt = ManchesterFootballConfig.SELECTED_YES
                } else {
                    indoorTxt = ManchesterFootballConfig.SELECTED_NO
                }

            }

            rg_flooad_lites.setOnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = view.findViewById(checkedId)
                if (radio.id == R.id.rb_floodlit_yes) {
                    floodLitTxt = ManchesterFootballConfig.SELECTED_YES
                } else {
                    floodLitTxt = ManchesterFootballConfig.SELECTED_NO
                }
            }

            tvSubmitForm.setOnClickListener {
                getValues()

                if (nameOfPitch.isEmpty()) {
                    name_of_pitch.error = "Please enter name of pitch"
                    name_of_pitch.requestFocus()
                    return@setOnClickListener
                } else if (locationName.isEmpty()) {
                    locaton_text.error = "Please enter your city name"
                    locaton_text.requestFocus()
                    return@setOnClickListener
                } else if (typesOfPitches.isEmpty()) {
                    popUp = AlertMessageDialog.newInstance("Please select pitch type!")
                    popUp?.show(childFragmentManager, "")
                    return@setOnClickListener
                } else if (changingRoom.isEmpty()) {
                    popUp =
                        AlertMessageDialog.newInstance("Please select changing room you want or not!")
                    popUp?.show(childFragmentManager, "")
                    return@setOnClickListener
                } else if (onSiteParking.isEmpty()) {
                    popUp =
                        AlertMessageDialog.newInstance("Please select site parking you want or not!")
                    popUp?.show(childFragmentManager, "")
                    return@setOnClickListener
                } else if (indoorTxt.isEmpty()) {
                    popUp =
                        AlertMessageDialog.newInstance("Please select you want indoor pitch or not!")
                    popUp?.show(childFragmentManager, "")
                    return@setOnClickListener
                } else if (floodLitTxt.isEmpty()) {
                    popUp =
                        AlertMessageDialog.newInstance("Please select you want flood lites or not!")
                    popUp?.show(childFragmentManager, "")
                    return@setOnClickListener
                } else {

                    showProgress1Dialog(true)

                    val selectedTimeList = ArrayList<String>()
                    val postPitchId = getRandomString(7)
                    val uploadPitchMap = hashMapOf(
                        "pitchId" to postPitchId,
                        "nameOfPitch" to nameOfPitch,
                        "locationName" to locationName,
                        "typesOfPitches" to typesOfPitches,
                        "changeRoom" to changingRoom,
                        "onSiteParking" to onSiteParking,
                        "indoorTxt" to indoorTxt,
                        "floodLitTxt" to floodLitTxt,
                        "selectedTime" to selectedTimeList,
                        "visibility" to "true"
                    )

                    db.collection("Football Pitches").document(postPitchId).set(uploadPitchMap)
                        .addOnCompleteListener(
                            OnCompleteListener {

                                if (it.isSuccessful) {
                                    showProgress1Dialog(false)
                                    KeyboardUtils.hideKeyboard(requireActivity())
                                    popUp =
                                        AlertMessageDialog.newInstance("Your Foot ball pitch upload successfully")
                                    popUp?.show(childFragmentManager, "")

                                } else {
                                    showProgress1Dialog(false)
                                }

                            })

                }

            }

            tvUploadPitch.setText(getString(R.string.upload_football_pitch))
            ivEdit.visibility = View.VISIBLE

            ivEdit.setOnClickListener {
                locaton_text.isEnabled = true
                locaton_text.requestFocus()
            }

        } else {

            tvSubmitForm.text = "SEND"

            name_of_pitch.isEnabled = false
            name_of_pitch.setText(footballPitchModel.nameOfPitch.toString())
            ivEdit.visibility = View.GONE
            locaton_text.setText(footballPitchModel.locationName)

            tvUploadPitch.setText("PITCH DETAILS")
            if (footballPitchModel.typesOfPitches.equals(ManchesterFootballConfig.ASTRO_TURF_PITCH)) {
                rb_astro_turf.isEnabled = true
                rb_grass_pitch.isEnabled = false
                rb_astro_turf.isChecked = true
                rb_grass_pitch.isChecked = false

            } else {
                rb_astro_turf.isEnabled = false
                rb_grass_pitch.isEnabled = true
                rb_astro_turf.isChecked = false
                rb_grass_pitch.isChecked = true
            }
            if (footballPitchModel.changeRoom.equals(ManchesterFootballConfig.SELECTED_YES)) {
                rb_change_room_yes.isEnabled = true
                rb_change_room_no.isEnabled = false
                rb_change_room_yes.isChecked = true
                rb_change_room_no.isChecked = false

            } else {
                rb_change_room_yes.isEnabled = false
                rb_change_room_no.isEnabled = true
                rb_change_room_yes.isChecked = false
                rb_change_room_no.isChecked = true
            }

            if (footballPitchModel.onSiteParking.equals(ManchesterFootballConfig.SELECTED_YES)) {
                rb_site_parking_yes.isEnabled = true
                rb_site_parking_no.isEnabled = false
                rb_site_parking_yes.isChecked = true
                rb_site_parking_no.isChecked = false
            } else {
                rb_site_parking_yes.isEnabled = false
                rb_site_parking_no.isEnabled = true
                rb_site_parking_yes.isChecked = false
                rb_site_parking_no.isChecked = true
            }

            if (footballPitchModel.indoorTxt.equals(ManchesterFootballConfig.SELECTED_YES)) {
                rb_indoor_yes.isEnabled = true
                rb_indoor_no.isEnabled = false
                rb_indoor_yes.isChecked = true
                rb_indoor_no.isChecked = false
            } else {
                rb_indoor_yes.isEnabled = false
                rb_indoor_no.isEnabled = true
                rb_indoor_yes.isChecked = false
                rb_indoor_no.isChecked = true
            }


            if (footballPitchModel.floodLitTxt.equals(ManchesterFootballConfig.SELECTED_YES)) {
                rb_floodlit_yes.isEnabled = true
                rb_floodlit_no.isEnabled = false
                rb_floodlit_yes.isChecked = true
                rb_floodlit_no.isChecked = false
            } else {
                rb_floodlit_yes.isEnabled = false
                rb_floodlit_no.isEnabled = true
                rb_floodlit_yes.isChecked = false
                rb_floodlit_no.isChecked = true
            }

            tvSubmitForm.setOnClickListener {
                val mPopup = BookPitchDialog(this)
                mPopup.show(childFragmentManager, "")
            }

        }

    }



    private fun getRandomString(sizeOfRandomString: Int): String {
        val random = Random()
        val sb = StringBuilder(sizeOfRandomString)
        for (i in 0 until sizeOfRandomString)
            sb.append(ALLOWED_CHARACTERS[random.nextInt(ALLOWED_CHARACTERS.length)])
        return sb.toString()
    }

    private fun getValues() {
        nameOfPitch = name_of_pitch.text.toString()
        locationName = locaton_text.text.toString()
    }

    override fun onClickBook(selectedDate: String, timeFrom: String, toFrom: String) {
        showProgress1Dialog(true)
        val jsonStrUserProfile =
            ManchesterFootballConfig.getUserProfileSharedPref(context, ManchesterFootballConfig.USER_PROFILE_KEY)
        if (!jsonStrUserProfile.isNullOrEmpty()) {
            val profileModel =
                fromJson(
                    jsonStrUserProfile,
                    object : TypeToken<LoginUserModel>() {

                    }.getType()
                ) as LoginUserModel
            val bookingId = getRandomString(8)
            val bookPitch = hashMapOf(
                "bookingId" to bookingId,
                "userId" to profileModel.userId,
                "userName" to profileModel.userName,
                "nameOfPitch" to footballPitchModel.nameOfPitch,
                "locationName" to footballPitchModel.locationName,
                "typesOfPitches" to footballPitchModel.typesOfPitches,
                "changeRoom" to footballPitchModel.changeRoom,
                "onSiteParking" to footballPitchModel.onSiteParking,
                "indoorTxt" to footballPitchModel.indoorTxt,
                "floodLitTxt" to footballPitchModel.floodLitTxt,
                "pitchId" to footballPitchModel.pitchId,
                "selectedDate" to selectedDate,
                "selectedTime" to timeFrom,
                "paymentMethod" to toFrom
            )


            db.collection("Pitches which are book").whereEqualTo("pitchId", footballPitchModel.pitchId).get()
                .addOnCompleteListener {

                    val timeArrayList = ArrayList<GetTimeAndDateForBooking?>()
                    if (it.isSuccessful) {


                        for (i in it.result?.documents!!) {
                            timeArrayList.add(GetTimeAndDateForBooking(i.getString("selectedTime"), i.getString("selectedDate")))
                        }

                        for (j in timeArrayList){
                            if (j?.selectedTime.equals(timeFrom) && j?.selectedDate.equals(selectedDate)){
                                showProgress1Dialog(false)
                                val popup = AlertMessageDialog.newInstance("We are sorry this time slot already book you can choose any other")
                                popup.show(childFragmentManager, "")
                                return@addOnCompleteListener
                            }
                        }

                        db.collection("Pitches which are book").document(bookingId).set(bookPitch)
                            .addOnCompleteListener(
                                OnCompleteListener {

                                    if (it.isSuccessful) {

                                        val selectedTimeArray = ArrayList<String>()
                                        selectedTimeArray.add(timeFrom)

                                        val hashMap: HashMap<String, Any> = hashMapOf(
                                            "selectedTime" to selectedTimeArray,
                                            "selectedDate" to selectedDate
                                        )
                                        db.collection("Football Pitches").document(footballPitchModel.pitchId).update(hashMap).addOnCompleteListener {

                                            if (it.isSuccessful){
                                                showProgress1Dialog(false)
                                                KeyboardUtils.hideKeyboard(requireActivity())
                                                val popUp =
                                                    AlertMessageDialog.newInstance("Your Foot ball pitch successfully booked!!!")
                                                popUp.show(childFragmentManager, "")
                                                requireActivity().onBackPressed()
                                            }
                                        }

                                    } else {
                                        showProgress1Dialog(false)
                                    }

                                })
                    }

            }



        }

    }

    private fun fromJson(jsonString: String?, type: Type): Any {
        return Gson().fromJson(jsonString, type)
    }

    data class GetTimeAndDateForBooking(
         val selectedTime: String?,
         val selectedDate: String?
    )
}


