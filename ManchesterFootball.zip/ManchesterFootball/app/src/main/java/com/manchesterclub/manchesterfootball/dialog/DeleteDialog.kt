package com.manchesterclub.manchesterfootball.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.models.BookingModel
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import kotlinx.android.synthetic.main.delete_dialog.*

class DeleteDialog(var footballPitchModel: FootballPitchModel? = null, var bookingModel: BookingModel? = null, var actionListener: ActionListener) : DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.delete_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        yes_btn.setOnClickListener {
            actionListener.onClickYes(footballPitchModel, bookingModel)
        }

        no_btn.setOnClickListener {
            actionListener.onClickNo()
        }
    }

    interface ActionListener{
        fun onClickYes(footballPitchModel: FootballPitchModel? = null, bookingModel: BookingModel? = null)
        fun onClickNo()
    }


}
