package com.manchesterclub.manchesterfootball.utils

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.manchesterclub.manchesterfootball.models.LoginUserModel

class ManchesterFootballConfig {

    companion object{
        var loginUserModel : LoginUserModel? = null
        var myLocationCityName: String = ""
        val ASTRO_TURF_PITCH = "1"
        val GRASS_PITCH = "2"
        val SELECTED_YES = "YES"
        val SELECTED_NO = "NO"
        val USER_PROFILE_KEY = "user_profile"



        fun saveUserProfilePreference(context: Context?, profileModel: LoginUserModel, key: String){
            val mPref = context?.getSharedPreferences(USER_PROFILE_KEY, Context.MODE_PRIVATE)
            Log.d("Value", mPref.toString())
            val prefsEditor = mPref?.edit()
            val gson = Gson()
            val json = gson.toJson(profileModel)
            prefsEditor?.putString(key, json)
            prefsEditor?.commit()
        }

        fun getUserProfileSharedPref(context: Context?, key: String): String? {
            val prefs = context?.getSharedPreferences(USER_PROFILE_KEY, Context.MODE_PRIVATE)
            return prefs?.getString(key, "")
        }
    }



}