package com.manchesterclub.manchesterfootball.models

class BookingModel(
    val locationName: String, val nameOfPitch: String,
    val pitchId: String, val paymentMethod: String,
    val selectedDate: String, val selectedTime: String,
    val userName: String,val bookingId: String, var visibility: String? = ""
)