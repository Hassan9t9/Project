package com.manchesterclub.manchesterfootball.models

import java.io.Serializable

class FootballPitchModel(
    val pitchId: String,
    val nameOfPitch: String?,
    val locationName: String,
    val typesOfPitches: String,
    val changeRoom: String,
    val onSiteParking: String,
    val indoorTxt: String,
    val floodLitTxt: String,
    val selectedBookTime: ArrayList<String?>?,
    val selectedDate: String = "",
    val visibilty: String = "true"
) : Serializable