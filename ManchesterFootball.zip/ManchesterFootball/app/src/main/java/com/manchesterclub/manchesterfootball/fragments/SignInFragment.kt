package com.manchesterclub.manchesterfootball.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import com.acclivousbyte.gobblecustomer.view.dialog.AlertMessageDialog
import com.google.android.gms.tasks.OnCompleteListener

import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.extensions.isOnline
import com.manchesterclub.manchesterfootball.models.LoginUserModel
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.fragment_sign_in.*

/**
 * A simple [Fragment] subclass.
 */
class SignInFragment : BaseFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_sign_in, container, false)
        view.findViewById<RelativeLayout>(R.id.create_account_layout).setOnClickListener {
            replaceFragment(SignUpFragment(), true, 2)
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnLogin.setOnClickListener {


            if (!isValidEmail(etUserEmail.text.toString())) {
                etUserEmail.error = "Please enter a valid email address"
                etUserEmail.requestFocus()
            } else if (etUserPassword.text.length < 6) {
                etUserPassword.error = "Please enter minimum six digit valid password"
                etUserPassword.requestFocus()
            } else {
                showProgress1Dialog(true)
                if (isOnline(requireContext())) {
                    db.collection("Users").whereEqualTo("Email", etUserEmail.text.toString()).get()
                        .addOnCompleteListener {
                            if (it.isSuccessful) {
                                showProgress1Dialog(false)
                                for (i in it.result?.documents!!) {
                                    ManchesterFootballConfig.loginUserModel = LoginUserModel(
                                        i.getString("UserId"),
                                        i.getString("Email"),
                                        i.getString("Password"),
                                        i.getString("Phone Number"),
                                        i.getString("User Name"),
                                        i.getString("status"),
                                        i.getString("admin")
                                    )
                                }
                                if (ManchesterFootballConfig.loginUserModel == null) {
                                    val popUp =
                                        AlertMessageDialog.newInstance("Please enter a valid email and password!")
                                    popUp.show(childFragmentManager, "")
                                } else {

                                    ManchesterFootballConfig.saveUserProfilePreference(requireContext(),
                                        ManchesterFootballConfig.loginUserModel!!,
                                        ManchesterFootballConfig.USER_PROFILE_KEY)


                                    sessionManager.setLoginString("true")
                                    replaceFragment(HomeFragment(), false, 2)
                                }

                            }
                        }.addOnFailureListener {
                            Log.d("exception", it.message.toString())

                        }
                } else {
                    showProgress1Dialog(false)
                    val popUp =
                        AlertMessageDialog.newInstance("Please check your internet connection!")
                    popUp.show(childFragmentManager, "")
                }


            }
        }

    }


}
