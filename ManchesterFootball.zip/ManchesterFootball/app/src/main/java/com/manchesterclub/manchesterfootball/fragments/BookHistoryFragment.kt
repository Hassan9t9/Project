package com.manchesterclub.manchesterfootball.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.acclivousbyte.gobblecustomer.view.dialog.AlertMessageDialog
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.QuerySnapshot
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.adapters.BookingHistoryAdapter
import com.manchesterclub.manchesterfootball.adapters.BookingPitchAdapter
import com.manchesterclub.manchesterfootball.dialog.BookPitchDialog
import com.manchesterclub.manchesterfootball.dialog.DeleteDialog
import com.manchesterclub.manchesterfootball.extensions.isOnline
import com.manchesterclub.manchesterfootball.models.BookingModel
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import com.manchesterclub.manchesterfootball.models.LoginUserModel
import com.manchesterclub.manchesterfootball.utils.KeyboardUtils
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.fragment_book_history.*
import java.lang.reflect.Type
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
class BookHistoryFragment : BaseFragment(), BookingHistoryAdapter.ItemClickListener,
    DeleteDialog.ActionListener, BookPitchDialog.ItemClickBook {


    lateinit var footballPitchModel: BookingModel

    val footballPitchList: MutableList<BookingModel> = mutableListOf()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_book_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        ivBackScreen.setOnClickListener {
            requireActivity().onBackPressed()
        }

        val jsonStrUserProfile =
            ManchesterFootballConfig.getUserProfileSharedPref(
                context,
                ManchesterFootballConfig.USER_PROFILE_KEY
            )
        if (!jsonStrUserProfile.isNullOrEmpty()) {
            val profileModel =
                fromJson(
                    jsonStrUserProfile,
                    object : TypeToken<LoginUserModel>() {

                    }.getType()
                ) as LoginUserModel

            showProgress1Dialog(true)

            getBookingsOfUser(profileModel)

        }
    }

    fun getBookingsOfUser(profileModel: LoginUserModel){
        if (ManchesterFootballConfig.loginUserModel?.admin.isNullOrEmpty().not()) {

            if (isOnline(requireContext())) {
                db.collection("Pitches which are book").get()
                    .addOnCompleteListener(object : OnCompleteListener<QuerySnapshot> {
                        override fun onComplete(p0: Task<QuerySnapshot>) {
                            if (p0.isSuccessful) {
                                footballPitchList.clear()
                                val selectedTimeList = ArrayList<String?>()
                                for (i in p0.result?.documents!!) {

                                    selectedTimeList.add(i.getString("selectedTime"))
                                    footballPitchModel = BookingModel(
                                        i.getString("locationName").toString(),
                                        i.getString("nameOfPitch").toString(),
                                        i.getString("pitchId").toString(),
                                        i.getString("paymentMethod").toString(),
                                        i.getString("selectedDate").toString(),
                                        i.getString("selectedTime").toString(),
                                        i.getString("userName").toString(),
                                        i.getString("bookingId").toString(),
                                        i.getString("visibility").toString()

                                    )

                                    if (footballPitchModel.visibility.isNullOrEmpty() || footballPitchModel.visibility == "null")
                                        footballPitchList.add(footballPitchModel)

                                }


                                setAdapter(footballPitchList)

                                showProgress1Dialog(false)
                            }
                        }

                    }).addOnFailureListener {
                        val popUp = AlertMessageDialog.newInstance(it.message.toString())
                        popUp.show(childFragmentManager, "")
                    }
            } else {
                val popUp =
                    AlertMessageDialog.newInstance("Please check your internet connection")
                popUp.show(childFragmentManager, "")
            }


        } else {

            if (isOnline(requireContext())) {
                db.collection("Pitches which are book")
                    .whereEqualTo("userId", profileModel.userId).get()
                    .addOnCompleteListener(object : OnCompleteListener<QuerySnapshot> {
                        override fun onComplete(p0: Task<QuerySnapshot>) {
                            if (p0.isSuccessful) {
                                footballPitchList.clear()
                                for (i in p0.result?.documents!!) {

                                    footballPitchModel = BookingModel(
                                        i.getString("locationName").toString(),
                                        i.getString("nameOfPitch").toString(),
                                        i.getString("pitchId").toString(),
                                        i.getString("paymentMethod").toString(),
                                        i.getString("selectedDate").toString(),
                                        i.getString("selectedTime").toString(),
                                        i.getString("userName").toString(),
                                        i.getString("bookingId").toString()
                                    )

                                    footballPitchList.add(footballPitchModel)

                                }

                                setAdapter(footballPitchList)

                                showProgress1Dialog(false)
                            }
                        }

                    }).addOnFailureListener {
                        val popUp = AlertMessageDialog.newInstance(it.message.toString())
                        popUp.show(childFragmentManager, "")
                    }
            } else {
                val popUp =
                    AlertMessageDialog.newInstance("Please check your internet connection")
                popUp.show(childFragmentManager, "")
            }

        }
    }

    fun setAdapter(footballPitchList: MutableList<BookingModel>) {
        val bookingPitchAdapter = BookingHistoryAdapter(requireContext(), footballPitchList, this)

        rv_football_pitch_list.let {
            it.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            it.adapter = bookingPitchAdapter
        }
    }

    override fun openDetail(notify: BookingModel) {

    }

    var deleteDialog: DeleteDialog? = null

    override fun deleteBooking(notify: BookingModel) {
        deleteDialog = DeleteDialog(null, notify, this)
        deleteDialog?.show(childFragmentManager, "")
    }

    lateinit var rebookPitchModel: BookingModel
    lateinit var mPopup: BookPitchDialog
    override fun rebookPitch(notify: BookingModel) {
        rebookPitchModel = notify
        mPopup = BookPitchDialog(this)
        mPopup.show(childFragmentManager, "")
    }

    private fun fromJson(jsonString: String?, type: Type): Any {
        return Gson().fromJson(jsonString, type)
    }

    override fun onClickYes(footbalPitchModel: FootballPitchModel?, bookingModel: BookingModel?) {
        deleteDialog?.dismiss()
        showProgress1Dialog(true)

        val hashMap = hashMapOf(
            "visibility" to "false"
        )


        bookingModel?.bookingId?.let {
            db.collection("Pitches which are book").document(it).update(hashMap as Map<String, Any>)
                .addOnCompleteListener {

                    if (it.isSuccessful){
                        db.collection("Pitches which are book").get()
                            .addOnCompleteListener(object : OnCompleteListener<QuerySnapshot> {
                                override fun onComplete(p0: Task<QuerySnapshot>) {
                                    if (p0.isSuccessful) {
                                        footballPitchList.clear()
                                        val selectedTimeList = ArrayList<String?>()
                                        for (i in p0.result?.documents!!) {

                                            selectedTimeList.add(i.getString("selectedTime"))
                                            footballPitchModel = BookingModel(
                                                i.getString("locationName").toString(),
                                                i.getString("nameOfPitch").toString(),
                                                i.getString("pitchId").toString(),
                                                i.getString("paymentMethod").toString(),
                                                i.getString("selectedDate").toString(),
                                                i.getString("selectedTime").toString(),
                                                i.getString("userName").toString(),
                                                i.getString("bookingId").toString(),
                                                i.getString("visibility").toString()

                                            )

                                            if (footballPitchModel.visibility.isNullOrEmpty() || footballPitchModel.visibility == "null")
                                                footballPitchList.add(footballPitchModel)

                                        }

                                        setAdapter(footballPitchList)
                                        showProgress1Dialog(false)
                                    }
                                }
                            }).addOnFailureListener {
                                showProgress1Dialog(false)
                                val popUp = AlertMessageDialog.newInstance(it.message.toString())
                                popUp.show(childFragmentManager, "")
                            }
                    }
                }
        }
    }

    override fun onClickNo() {
        deleteDialog?.dismiss()
    }

    override fun onClickBook(selectedDate: String, timeFrom: String, toFrom: String) {
        showProgress1Dialog(true)
        mPopup.dismiss()
        val jsonStrUserProfile =
            ManchesterFootballConfig.getUserProfileSharedPref(
                context,
                ManchesterFootballConfig.USER_PROFILE_KEY
            )
        if (!jsonStrUserProfile.isNullOrEmpty()) {
            val profileModel =
                fromJson(
                    jsonStrUserProfile,
                    object : TypeToken<LoginUserModel>() {

                    }.getType()
                ) as LoginUserModel
            val bookingId = getRandomString(8)

            val bookPitch = hashMapOf(
                "bookingId" to rebookPitchModel.bookingId,
                "userId" to profileModel.userId,
                "userName" to profileModel.userName,
                "nameOfPitch" to rebookPitchModel.nameOfPitch,
                "locationName" to rebookPitchModel.locationName,
                "typesOfPitches" to "",
                "changeRoom" to "",
                "onSiteParking" to "",
                "indoorTxt" to "",
                "floodLitTxt" to "",
                "pitchId" to rebookPitchModel.pitchId,
                "selectedDate" to selectedDate,
                "selectedTime" to timeFrom,
                "paymentMethod" to toFrom
            )

            db.collection("Pitches which are book").whereEqualTo("pitchId", rebookPitchModel.pitchId).get()
                .addOnCompleteListener {

                    val timeArrayList = ArrayList<PostPitchFragment.GetTimeAndDateForBooking?>()
                    if (it.isSuccessful) {


                        for (i in it.result?.documents!!) {
                            timeArrayList.add(
                                PostPitchFragment.GetTimeAndDateForBooking(
                                    i.getString(
                                        "selectedTime"
                                    ), i.getString("selectedDate")
                                )
                            )
                        }

                        for (j in timeArrayList){
                            if (j?.selectedTime.equals(timeFrom) && j?.selectedDate.equals(selectedDate)){
                                showProgress1Dialog(false)
                                val popup = AlertMessageDialog.newInstance("We are sorry this time slot already book you can choose any other")
                                popup.show(childFragmentManager, "")
                                return@addOnCompleteListener
                            }
                        }

                        db.collection("Pitches which are book").document(bookingId).set(bookPitch)
                            .addOnCompleteListener(
                                OnCompleteListener {

                                    if (it.isSuccessful) {

                                        val selectedTimeArray = ArrayList<String>()
                                        selectedTimeArray.add(timeFrom)

                                        val hashMap: HashMap<String, Any> = hashMapOf(
                                            "selectedTime" to selectedTimeArray,
                                            "selectedDate" to selectedDate
                                        )
                                        db.collection("Football Pitches").document(footballPitchModel.pitchId).update(hashMap).addOnCompleteListener {

                                            if (it.isSuccessful){

                                                getBookingsOfUser(profileModel)
                                                //showProgress1Dialog(false)
//                                                KeyboardUtils.hideKeyboard(requireActivity())
//                                                val popUp =
//                                                    AlertMessageDialog.newInstance("Your Foot ball pitch successfully booked!!!")
//                                                popUp.show(childFragmentManager, "")
//                                                requireActivity().onBackPressed()
                                            }
                                        }

                                    } else {
                                        showProgress1Dialog(false)
                                    }

                                })
                    }

                }


        }
    }

    private fun getRandomString(sizeOfRandomString: Int): String {
        val random = Random()
        val sb = StringBuilder(sizeOfRandomString)
        for (i in 0 until sizeOfRandomString)
            sb.append(PostPitchFragment.ALLOWED_CHARACTERS[random.nextInt(PostPitchFragment.ALLOWED_CHARACTERS.length)])
        return sb.toString()
    }
}
