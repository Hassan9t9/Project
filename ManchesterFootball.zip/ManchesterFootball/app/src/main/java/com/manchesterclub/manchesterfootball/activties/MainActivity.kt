package com.manchesterclub.manchesterfootball.activties

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.fragments.SignInFragment
import com.manchesterclub.manchesterfootball.fragments.SplashFragment

class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        addFragment(SplashFragment(), false, 1)

    }
}
