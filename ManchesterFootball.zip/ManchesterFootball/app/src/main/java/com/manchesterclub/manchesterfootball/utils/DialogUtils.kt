package com.manchesterclub.manchesterfootball.utils

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import com.manchesterclub.manchesterfootball.R


public class DialogUtils {
    companion object {
        fun getProgressDialog(context: Context): AlertDialog {
            val dialogBuilder = AlertDialog.Builder(context)
            val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val dialogView = inflater.inflate(R.layout.progress_layout, null)
            dialogBuilder.setView(dialogView)

            //        ImageView spaceshipImage = (ImageView) dialogView.findViewById(R.id.image);
            //        ImageView imagebg1= (ImageView) dialogView.findViewById(R.id.imagebg1) ;
            //        ImageView imagebg2= (ImageView) dialogView.findViewById(R.id.imagebg2) ;

            //        AlphaAnimation anim2 = new AlphaAnimation(0.3f, 0.7f);
            //        anim2.setDuration(800);
            //        anim2.setRepeatCount(Animation.INFINITE);
            //        anim2.setRepeatMode(Animation.RESTART);
            //
            //        imagebg2.setAlpha(0.3f);
            //        imagebg2.startAnimation(anim2);
            //
            //        AlphaAnimation anim1 = new AlphaAnimation(0.7f, 1.0f);
            //        anim1.setDuration(800);
            //        anim1.setRepeatCount(Animation.INFINITE);
            //        anim1.setRepeatMode(Animation.RESTART);
            //
            //        imagebg1.setAlpha(0.7f);
            //        imagebg1.startAnimation(anim1);


            val alertDialog = dialogBuilder.create()
            alertDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            alertDialog.setCancelable(false)
            //alertDialog.show();

            return alertDialog
        }
    }
}