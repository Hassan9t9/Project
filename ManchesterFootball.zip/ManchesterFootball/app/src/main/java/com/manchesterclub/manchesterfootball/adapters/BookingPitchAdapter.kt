package com.manchesterclub.manchesterfootball.adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import androidx.recyclerview.widget.RecyclerView
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.pitch_items.view.*

class BookingPitchAdapter(
    private val context: Context,
    private var dataFilter: MutableList<FootballPitchModel>,
    private val listener: ItemClickListener
) :
    RecyclerView.Adapter<BookingPitchAdapter.BookingPitchViewHolder>() {

    private val mInflater: LayoutInflater = LayoutInflater.from(context)

    var bookList : MutableList<FootballPitchModel>

    init {
        this.bookList = dataFilter
    }

    val filter: Filter
        get() = object : Filter() {
            override fun performFiltering(charSequence: CharSequence): Filter.FilterResults {
                val charString = charSequence.toString()
                val filterValues = charString.split(",")
                val time = filterValues[0]
                val date = filterValues[1]
                if (time.isEmpty() || date.isEmpty()) {
                    dataFilter = bookList
                } else {
                    val filteredList = mutableListOf<FootballPitchModel>()
                    for (row in bookList) {

                        Log.d("yes ===>", row.selectedBookTime?.getOrElse(0) {""}.toString())
                        Log.d("yes ===>",bookList.size.toString())
                        val selectedBookTime: String = row.selectedBookTime?.getOrElse(0) {""}.toString()
                        val selectedDate = row.selectedDate

                        if (selectedBookTime.contains(time).not() && selectedDate.contains(date).not()) {
                                row.let { filteredList.add(it) }
                        }

                    }

                    dataFilter = filteredList
                }

                val filterResults = Filter.FilterResults()
                filterResults.values = dataFilter
                return filterResults
            }

            override fun publishResults(
                charSequence: CharSequence,
                filterResults: Filter.FilterResults
            ) {
                dataFilter = filterResults.values as MutableList<FootballPitchModel>
                notifyDataSetChanged()
            }
        }



    inner class BookingPitchViewHolder internal constructor(itemView: View) :
        RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {
            dataFilter.get(adapterPosition).let { listener.openDetail(it) }

        }

        val mLocationName = itemView.location_name
        val mPitchName = itemView.pitch_name
        val siteParking = itemView.on_site_parking
        val mFlodLite = itemView.flood_lit_txt
        val mIndoorTxt = itemView.indoor_txt
        val deleteBooking = itemView.delete_bookings

        init {
            itemView.setOnClickListener(this)
        }
    }

    interface ItemClickListener {
        fun openDetail(notify: FootballPitchModel)
        fun deleteBooking(notify: FootballPitchModel)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookingPitchViewHolder {
        val view = mInflater.inflate(R.layout.pitch_items, parent, false)
        return BookingPitchViewHolder(view)

    }

    override fun getItemCount(): Int {
        return dataFilter.size
    }

    override fun onBindViewHolder(holder: BookingPitchViewHolder, position: Int) {
        val item = dataFilter[position]

        holder.mLocationName.text = item.locationName
        holder.mPitchName.text = item.nameOfPitch
        holder.siteParking.text = item.onSiteParking
        holder.mFlodLite.text = item.floodLitTxt
        holder.mIndoorTxt.text = item.indoorTxt

        if (ManchesterFootballConfig.loginUserModel?.admin.equals("yes")){
            holder.deleteBooking.visibility = View.VISIBLE
        }else{
            holder.deleteBooking.visibility = View.GONE

        }

        holder.deleteBooking.setOnClickListener {
            listener.deleteBooking(item)
        }


    }

}