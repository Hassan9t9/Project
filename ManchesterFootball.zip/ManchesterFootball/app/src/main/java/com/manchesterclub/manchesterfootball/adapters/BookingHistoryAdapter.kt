package com.manchesterclub.manchesterfootball.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.models.BookingModel
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.booking_history_items.view.*

class BookingHistoryAdapter (
    private val context: Context,
    private var dataFilter: MutableList<BookingModel>,
    private val listener: ItemClickListener
) :
    RecyclerView.Adapter<BookingHistoryAdapter.BookingPitchViewHolder>() {

    private val mInflater: LayoutInflater = LayoutInflater.from(context)


    inner class BookingPitchViewHolder internal constructor(itemView: View) :
        RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {
            dataFilter.get(adapterPosition).let { listener.openDetail(it) }

        }

        val mLocationName = itemView.location_name
        val mPitchName = itemView.pitch_name
        val mUserNameLayout = itemView.user_name_layout
        val mUserName = itemView.user_name_tv
        val mSelectedTime = itemView.on_time_booking
        val mSelectedDate = itemView.date_of_booking_txt
        val mPaymentMethods = itemView.payment_methods
        val deleteBooking = itemView.delete_bookings
        val rebookPitch = itemView.rebook_booking

        init {
            itemView.setOnClickListener(this)
        }
    }

    interface ItemClickListener {
        fun openDetail(notify: BookingModel)
        fun deleteBooking(notify: BookingModel)
        fun rebookPitch(notify: BookingModel)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookingPitchViewHolder {
        val view = mInflater.inflate(R.layout.booking_history_items, parent, false)
        return BookingPitchViewHolder(view)

    }

    override fun getItemCount(): Int {
        return dataFilter.size
    }

    override fun onBindViewHolder(holder: BookingPitchViewHolder, position: Int) {
        val item = dataFilter[position]

        holder.mLocationName.text = item.locationName
        holder.mPitchName.text = item.nameOfPitch

        if (ManchesterFootballConfig.loginUserModel?.admin.equals("yes")){
            holder.mUserNameLayout.visibility = View.VISIBLE
        }else{
            holder.mUserNameLayout.visibility = View.GONE
        }
        holder.mUserName.text = item.userName
        holder.mSelectedDate.text = item.selectedDate
        holder.mSelectedTime.text = item.selectedTime
        holder.mPaymentMethods.text = item.paymentMethod

        holder.rebookPitch.setOnClickListener {
            listener.rebookPitch(item)
        }


        if (ManchesterFootballConfig.loginUserModel?.admin.isNullOrEmpty().not()){
            holder.deleteBooking.visibility = View.VISIBLE
        }else{
            holder.deleteBooking.visibility = View.GONE
        }

        holder.deleteBooking.setOnClickListener {
            listener.deleteBooking(item)
        }

    }

}