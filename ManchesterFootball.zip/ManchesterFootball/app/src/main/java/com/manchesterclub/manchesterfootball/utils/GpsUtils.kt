package com.example.legocatalog

import android.widget.Toast
import android.app.Activity
import android.content.IntentSender
import androidx.annotation.NonNull
import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Context
import android.location.LocationManager
import android.content.Context.LOCATION_SERVICE
import android.util.Log
import androidx.core.content.ContextCompat.getSystemService
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import android.content.Intent
import com.google.android.gms.location.*
import locationprovider.davidserrano.com.LocationProvider


class GpsUtils(private val context: Context) {
    private lateinit var callback: LocationProvider.LocationCallback
    private val mSettingsClient: SettingsClient
    private val mLocationSettingsRequest: LocationSettingsRequest
    private val locationManager: LocationManager
    private val locationRequest: LocationRequest
    lateinit var locationProvider: LocationProvider

    init {
        locationManager = context.getSystemService(LOCATION_SERVICE) as LocationManager
        mSettingsClient = LocationServices.getSettingsClient(context)
        locationRequest = LocationRequest.create()
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
        locationRequest.setInterval(10 * 1000)
        locationRequest.setFastestInterval(2 * 1000)
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)
        mLocationSettingsRequest = builder.build()
        //**************************
        builder.setAlwaysShow(true) //this is the key ingredient
        //**************************
    }

    // method for turn on GPS
    fun turnGPSOn(onGpsListener: onGpsListener?) {
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            onGpsListener?.gpsStatus(true)
        } else {
            mSettingsClient
                .checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(
                    context as Activity
                ) {
                    //  GPS is already enable, callback GPS status through listener
                    onGpsListener?.gpsStatus(true)
                }
                .addOnFailureListener(context, OnFailureListener { e ->
                    val statusCode = (e as ApiException).statusCode
                    when (statusCode) {
                        LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> try {
                            // Show the dialog by calling startResolutionForResult(), and check the
                            // result in onActivityResult().
                            val rae = e as ResolvableApiException
                            rae.startResolutionForResult(
                                context,
                                1234
                            )
                        } catch (sie: IntentSender.SendIntentException) {
                            Log.i(TAG, "PendingIntent unable to execute request.")
                        }

                        LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE -> {
                            val errorMessage =
                                "Location settings are inadequate, and cannot be " + "fixed here. Fix in Settings."
                            Log.e(TAG, errorMessage)
                            Toast.makeText(context, errorMessage, Toast.LENGTH_LONG)
                                .show()
                        }
                    }
                })
        }
    }


    fun locationListener(){
         callback = object : locationprovider.davidserrano.com.LocationProvider.LocationCallback {
            override fun locationRequestStopped() {
                currentLocationListener.locationRequestStoppedListener()
            }

            override fun onNewLocationAvailable(lat: Float, lon: Float) {
                currentLocationListener.onNewLocationAvailableListener(lat,lon)
            }

            override fun locationServicesNotEnabled() {
                currentLocationListener.locationServicesNotEnabledListener()
            }

            override fun updateLocationInBackground(lat: Float, lon: Float) {
                currentLocationListener.updateLocationInBackgroundListener(lat,lon)
            }

            override fun networkListenerInitialised() {
                currentLocationListener.networkListenerInitialisedListener()
            }
        }

    }



    interface onGpsListener {
        fun gpsStatus(isGPSEnable: Boolean)
    }

    lateinit var currentLocationListener : CurrentLocationListener

    fun setLocatoinListener(currentLocationListener: CurrentLocationListener){
        this.currentLocationListener = currentLocationListener
        locationProvider = LocationProvider.Builder().setContext(context).setListener(callback).create()
        locationProvider.requestLocation()
    }

    interface CurrentLocationListener {

        fun locationRequestStoppedListener()
        fun onNewLocationAvailableListener(lat: Float, lon: Float)
        fun updateLocationInBackgroundListener(lat: Float, lon: Float)
        fun locationServicesNotEnabledListener()
        fun networkListenerInitialisedListener()

    }
}