package com.manchesterclub.manchesterfootball.fragments

import android.location.Geocoder
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.legocatalog.GpsUtils
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import com.manchesterclub.manchesterfootball.models.LoginUserModel
import com.manchesterclub.manchesterfootball.utils.LocationAddressUtils
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.fragment_home.view.*
import java.io.IOException
import java.lang.reflect.Type
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
class HomeFragment : BaseFragment() {

    private var cityName = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val jsonStrUserProfile =
            ManchesterFootballConfig.getUserProfileSharedPref(context, ManchesterFootballConfig.USER_PROFILE_KEY)
        if (!jsonStrUserProfile.isNullOrEmpty()) {
            val profileModel =
                fromJson(
                    jsonStrUserProfile,
                    object : TypeToken<LoginUserModel>() {

                    }.getType()
                ) as LoginUserModel

            ManchesterFootballConfig.loginUserModel = profileModel

            if (ManchesterFootballConfig.loginUserModel!!.admin.isNullOrEmpty().not()){
                view.upload_pitch.visibility = View.VISIBLE
            }else{
                view.upload_pitch.visibility = View.GONE
            }

        }



        GpsUtils(requireContext()).turnGPSOn(object: GpsUtils.onGpsListener{
            override fun gpsStatus(isGPSEnable: Boolean) {
                if(isGPSEnable)
                {
                    val latLng = LocationAddressUtils.getCurrentLocation(requireContext())

                    locationAddress(latLng)

                    Log.d("cityName1", cityName)
                    ManchesterFootballConfig.myLocationCityName = cityName

                }
            }
        })

        view.myBookingHistory.setOnClickListener {
            replaceFragment(BookHistoryFragment(), true, 2)
        }

        view.upload_pitch.setOnClickListener {
            val selectTimeList = ArrayList<String?>()
            val footballPitchModel = FootballPitchModel("","","","","","","","", selectTimeList)

            replaceFragment(PostPitchFragment.newInstance(footballPitchModel, false), true, 2)
        }

        view.add_football_pitch.setOnClickListener {
            replaceFragment(BookFootballPitchFragment(), true, 2)
        }

        view.btn_logout.setOnClickListener {
            showProgress1Dialog(true)
            Handler().postDelayed({
                sessionManager.setLoginString("")
                showProgress1Dialog(false)
                replaceFragment(SignInFragment(), false, 2)
            }, 2000)
        }


    }

    private fun fromJson(jsonString: String?, type: Type): Any {
        return Gson().fromJson(jsonString, type)
    }

    fun locationAddress(p0: LatLng) {
        try {

            val geocoder = Geocoder(context, Locale.getDefault())

            val addresses = geocoder.getFromLocation(
                p0.latitude, p0.longitude,
                1
            )
            if (!addresses[0].locality.isNullOrEmpty()) {
                cityName = addresses[0].locality
            }

            } catch (ioException: IOException) {
            // Catch network or other I/O problems.
        } catch (illegalArgumentException: IllegalArgumentException) {
            // Catch invalid latitude or longitude values.
        }
    }


}
