package com.manchesterclub.manchesterfootball.activties

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.utils.FragmentUtil
import com.manchesterclub.manchesterfootball.utils.SessionManager

@SuppressLint("Registered")
open class BaseActivity : AppCompatActivity(){

    lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sessionManager = SessionManager(this)

    }


    fun addFragment(fragment: Fragment, addToBackStack: Boolean, animationType: Int) {

        FragmentUtil.addFragment(
            this,
            fragment,
            R.id.fragment_container,
            addToBackStack,
            animationType
        )
    }

    fun replaceFragment(fragment: Fragment, addToBackStack: Boolean, animationType: Int) {

        FragmentUtil.replaceFragment(
            this,
            fragment,
            R.id.fragment_container,
            addToBackStack,
            animationType
        )
    }
}