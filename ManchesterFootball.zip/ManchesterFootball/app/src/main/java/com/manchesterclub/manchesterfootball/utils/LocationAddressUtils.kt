package com.manchesterclub.manchesterfootball.utils

import android.content.Context
import android.util.Log
import com.google.android.gms.maps.model.LatLng
import locationprovider.davidserrano.com.LocationProvider

class LocationAddressUtils {

    companion object {
        fun getCurrentLocation(context: Context): LatLng {
            lateinit var latLng: LatLng
            val callback = object : LocationProvider.LocationCallback {


                override fun onNewLocationAvailable(lat: Float, lon: Float) {
                    //location update
                    latLng = LatLng(lat.toDouble(), lon.toDouble())

                }

                override fun locationServicesNotEnabled() {
                    //failed finding a location
                }

                override fun updateLocationInBackground(lat: Float, lon: Float) {
                    //if a listener returns after the main locationAvailable callback, it will go here
                }

                override fun networkListenerInitialised() {
                    //when the library switched from GPS only to GPS & network
                }

                override fun locationRequestStopped() {

                }
            }

            val locationProvider = LocationProvider.Builder()
                .setContext(context)
                .setListener(callback)
                .create()

            //start getting location
            locationProvider.requestLocation()
            return latLng
        }
    }
}