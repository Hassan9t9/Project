package com.manchesterclub.manchesterfootball.utils

import android.content.Context
import android.content.SharedPreferences


class SessionManager {

    var context: Context? = null
    var pref: SharedPreferences

    constructor(context: Context) {
        this.context = context
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }


    fun isSignUp(): Boolean {
        return !getSignUp().isNullOrEmpty();
    }

    fun isSignIn(): Boolean {
        return !getSignIn().isNullOrEmpty();
    }

//    fun saveUserDetail(userLoginModel: UserLoginModel?){
//
//        val prefsEditor = pref.edit()
//        if(userLoginModel!=null) {
//
//            val gson = Gson()
//            val json = gson.toJson(userLoginModel)
//            setAuthenticationToken(userLoginModel.jwtToken!!)
//            setUserId("" + userLoginModel.id)
//            setFirstName(userLoginModel.name)
//            setEmail(userLoginModel.email)
//            setPhone(userLoginModel.phone)
//            prefsEditor.putString("MyObject", json)
//            prefsEditor.commit()
//        }
//        else
//        {
//            prefsEditor.putString("MyObject", null)
//            prefsEditor.commit()
//        }
//    }
//
//    fun getUserDetail(): UserLoginModel?{
//        val gson = Gson()
//        val json = pref.getString("MyObject", "")
//        val obj = gson.fromJson<UserLoginModel>(json, UserLoginModel::class.java!!)
//        return obj
//    }


    fun setLoginString(loginString: String){
        with(pref.edit()) {
            putString(PHONENUMBER, loginString)
            commit()
        }
    }

    fun getLoginString(): String {
        return pref.getString(PHONENUMBER, "")!!
    }


    fun setAppThemeString(theme: String){
        with(pref.edit()) {
            putString(THEME, theme)
            commit()
        }
    }

    fun getAppThemeString(): String {
        return pref.getString(THEME, "")!!
    }

    fun setUserType(type: String){
        with(pref.edit()) {
            putString(TYPE_OF_USER, type)
            commit()
        }
    }

    fun getUserType(): String {
        return pref.getString(TYPE_OF_USER, "")!!
    }

    fun setLicenceImgUrl(image: String){
        with(pref.edit()) {
            putString(LICENCE_IMG_URL, image)
            commit()
        }
    }

    fun getLicenceImg(): String {
        return pref.getString(LICENCE_IMG_URL, "")!!
    }

    fun setMobileNumber(phoneNumber: String) {
        with(pref.edit()) {
            putString(TOKEN, phoneNumber)
            commit()
        }

    }

    fun getMobileNumber(): String {
        return pref.getString(TOKEN, "")!!
    }

    fun setAddressDelivery(phoneNumber: String) {
        with(pref.edit()) {
            putString(TOKEN, phoneNumber)
            commit()
        }

    }

    fun getAddresssDelivery(): String {
        return pref.getString(TOKEN, "")!!
    }

    fun setSignUp(signUpEmail: String) {
        with(pref.edit()) {
            putString(SIGNUPEMAIL, signUpEmail)
            commit()
        }
    }

    fun getSignUp(): String {
        return pref.getString(SIGNUPEMAIL, "")!!
    }

    fun setSignIn(signInEmail: String) {
        with(pref.edit()) {
            putString(SIGNINEMAIL, signInEmail)
            commit()
        }
    }

    fun getSignIn(): String {
        return pref.getString(SIGNINEMAIL, "")!!
    }



    fun setDrivingLicenceNumber(licenceNo: String?) {
        with(pref.edit()) {
            putString(KEY_LICENCE_NO, licenceNo)
            commit()
        }
    }

    fun getDrivingLicenceNo(): String {
        return pref.getString(KEY_LICENCE_NO, "")!!
    }

    fun setFirstName(firstName: String?) {
        with(pref.edit()) {
            putString(KEY_NAME, firstName)
            commit()
        }
    }

    fun getFirstName(): String {
        return pref.getString(KEY_NAME, "")!!
    }

    fun setUserId(userId: String?) {
        with(pref.edit()) {
            putString(USER_ID, userId)
            commit()
        }
    }

    fun getUserId(): String {
        return pref.getString(USER_ID, "")!!
    }

    fun setEmail(email: String?) {
        with(pref.edit()) {
            putString(KEY_EMAIL, email)
            commit()
        }
    }

    fun getEmail(): String {
        return pref.getString(KEY_EMAIL, "")!!
    }




    fun setProfileImage(profileImage: String) {
        with(pref.edit()) {
            putString(KEY_USERIMAGE, profileImage)
            commit()
        }
    }



    fun setBirthday(birthday: String) {
        with(pref.edit()) {
            putString(KEY_BIRTHDAY, birthday)
            commit()
        }
    }




    fun setFCM(fcm: String) {
        with(pref.edit()) {
            putString(KEY_FCM, fcm)
            commit()
        }
    }



    fun setAddressLine1(addresLine1: String?) {
        with(pref.edit()) {
            putString(ADDRESS_LINE_1, addresLine1)
            commit()
        }
    }



    fun setCnic(cnic: String) {
        with(pref.edit()) {
            putString(KEY_CNIC, cnic)
            commit()
        }
    }

    fun getAddressLine1(): String {
        return pref.getString(ADDRESS_LINE_1, "")!!
    }

    fun setAddressLine2(addresLine2: String) {
        with(pref.edit()) {
            putString(ADDRESS_LINE_2, addresLine2)
            commit()
        }
    }



    fun setCountry(country: String?) {
        with(pref.edit()) {
            putString(COUNTRY, country)
            commit()
        }
    }

    fun setCnicBackImage(cnicBackImage: String) {
        with(pref.edit()) {
            putString(KEY_CNIC_BACK_IMAGE, cnicBackImage)
            commit()
        }
    }


    fun getCountry(): String {
        return pref.getString(COUNTRY, "")!!
    }

    fun setStateRegionProvince(str: String?) {
        with(pref.edit()) {
            putString(STATE_REGION_PROVINCE, str)
            commit()
        }
    }

    fun getStateRegionProvince(): String {
        return pref.getString(STATE_REGION_PROVINCE, "")!!
    }

    fun setZip(zip: String?) {
        with(pref.edit()) {
            putString(ZIP, zip)
            commit()
        }
    }


    fun setDeviceId(deviceId: String) {
        with(pref.edit()) {
            putString(DEVICE_ID, deviceId)
            commit()
        }
    }

    fun getDeviceId(): String {
        return pref.getString(DEVICE_ID, "")!!
    }

    fun setSuperAdmin(deviceId: String) {
        with(pref.edit()) {
            putString(ADMIN_USER, deviceId)
            commit()
        }
    }

    fun getSuperAdmn(): String {
        return pref.getString(ADMIN_USER, "")!!
    }






    fun getLocale(): String {
        return "en"
    }

    companion object {
        val PREF_NAME: String = "app_pref"
        val TOKEN: String = "authentication_token"
        val SIGNUPEMAIL:String="sign_up_email"
        val SIGNINEMAIL:String="sign_in_email"
        val PHONENUMBER : String = "phoneNumber"
        val THEME : String = "theme"
        val TYPE_OF_USER: String = "request_type"
        val LICENCE_IMG_URL: String = "licence_img"
        val ADMIN_USER: String = "admin_user"

        val USER_ID: String = "user_id"
        val FIRST_NAME: String = "first_name"
        val LAST_NAME: String = "last_name"
        val EMAIL: String = "email"
        val PHONE: String = "phone"
        val GENDER: String = "gender"
        val AGE: String = "age"
        val PROFILE_IMAGE: String = "profile_image"
        val INVISIBLE: String = "invisible"

        val ADDRESS_LINE_1: String = "address_line_1"
        val ADDRESS_LINE_2: String = "address_line_2"
        val COUNTRY: String = "country"
        val CITY: String = "city"
        val STATE_REGION_PROVINCE = "state/region/province"
        val ZIP = "ZIP"

        val DEVICE_ID = "deviceid"
        val DEVICE_TOKEN = "devicetoken"
        val CART_ORDER_ID = "cartorderid"
        val PIMP_ID = "pimp_id"
        val LOCALE = "locale"
        val BEACONS = "beacons"


        val KEY_EMAIL = "email"
        val KEY_NAME = "vehicle_type"
        val KEY_LICENCE_NO = "licence_no"
        val KEY_USERID = "userid"
        val KEY_USERIMAGE = "userimage"
        val KEY_PHONENO = "phoneno"

        val KEY_BIRTHDAY = "birthday"
        val KEY_FCM = "key_fcm"
        val KEY_CNIC = "cnic"
        val KEY_CNIC_FRONT_IMAGE = "cnic_front_image"
        val KEY_CNIC_BACK_IMAGE = "cnic_back_image"




    }

}