package com.manchesterclub.manchesterfootball.dialog

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.DatePicker
import android.widget.RadioButton
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jaiselrahman.hintspinner.HintSpinnerAdapter

import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import com.manchesterclub.manchesterfootball.models.LoginUserModel
import com.manchesterclub.manchesterfootball.utils.ManchesterFootballConfig
import kotlinx.android.synthetic.main.fragment_book_pitch_dialog.*
import kotlinx.android.synthetic.main.fragment_book_pitch_dialog.view.*
import java.lang.reflect.Type
import java.util.*


class BookPitchDialog(val itemClickBook: ItemClickBook) : DialogFragment(),  DatePickerDialog.OnDateSetListener {

    private var selectedDate = ""
    lateinit var  db: FirebaseFirestore

    companion object{
        private val ALLOWED_CHARACTERS = "0123456789qwertyuiopasdfghjklzxcvbnm"
        private val ONLINE_PAYMENT = "Online payment"
        private val PAY_AT_PLACE = "Pay at place"
    }

    var paymentMethod = ""
    var selectedTime = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_book_pitch_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = FirebaseFirestore.getInstance()
        val selectedTimeArray = ArrayList<String>()

        selectedTimeArray.add("1PM to 2PM")
        selectedTimeArray.add("2PM to 3PM")
        selectedTimeArray.add("3PM to 4PM")
        selectedTimeArray.add("4PM to 5PM")
        selectedTimeArray.add("5PM to 6PM")
        selectedTimeArray.add("6PM to 7PM")
        selectedTimeArray.add("7PM to 8PM")
        selectedTimeArray.add("8PM to 9PM")
        selectedTimeArray.add("9PM to 10PM")
        selectedTimeArray.add("10PM to 11PM")
        selectedTimeArray.add("11PM to 12PM")

        time_selected_spinner.adapter = HintSpinnerAdapter(requireContext(), selectedTimeArray , "Select Time")

        time_selected_spinner.setSelection(0, false)
        time_selected_spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                return
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (view != null) {
                    val ss = parent?.getItemAtPosition(position-1)
                    selectedTime = ss.toString()
                    Log.d("selectedTime", selectedTime + position.toString())

                }
            }

        }
        view.selected_date.setOnClickListener {
            val dialog = DatePickerDialog(requireContext(),this, Calendar.YEAR, Calendar.MONTH, Calendar.DAY_OF_MONTH)
            dialog.datePicker.setMinDate(Calendar.getInstance().timeInMillis)

            dialog.show()
        }


        view.rg_select_payment_method.setOnCheckedChangeListener { group, checkedId ->
            val radio: RadioButton = view.findViewById(checkedId)
            if (radio.id == R.id.rb_online_payment) {
                paymentMethod = ONLINE_PAYMENT
            } else {
                paymentMethod = PAY_AT_PLACE
            }
        }



        view.tvSubmitForm.setOnClickListener {
            if (selected_date.text.isEmpty()){
                selected_date.error = "Please select date when you book this pitch"
            }else if (selectedTime.isEmpty()){
                Toast.makeText(requireContext(), "Please select time when you want to pick", Toast.LENGTH_LONG).show()
            }else if (paymentMethod.isEmpty()){
                Toast.makeText(requireContext(), "Please select payment category", Toast.LENGTH_LONG).show()
            }else{

                itemClickBook.onClickBook(selectedDate, selectedTime, paymentMethod)
                dismiss()

            }
        }

    }

    private fun selectedTime(){




    }


    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        val getMonth = month+1
        val cal= Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month)
        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

        var monthConverted = ""+getMonth;

        if(getMonth<10){
            monthConverted = "0"+monthConverted;

        }

        selectedDate = ""+year+"-"+ monthConverted +"-"+dayOfMonth

        selected_date.setText(selectedDate)
    }

    private fun fromJson(jsonString: String?, type: Type): Any {
        return Gson().fromJson(jsonString, type)
    }

    private fun getRandomString(sizeOfRandomString: Int): String {
        val random = Random()
        val sb = StringBuilder(sizeOfRandomString)
        for (i in 0 until sizeOfRandomString)
            sb.append(ALLOWED_CHARACTERS[random.nextInt(ALLOWED_CHARACTERS.length)])
        return sb.toString()
    }

    interface ItemClickBook{
        fun onClickBook(selectedDate: String, timeFrom: String, toFrom: String)
    }

}
