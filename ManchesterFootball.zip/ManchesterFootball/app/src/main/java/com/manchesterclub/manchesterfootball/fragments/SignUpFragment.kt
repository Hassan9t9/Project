package com.manchesterclub.manchesterfootball.fragments

import android.R.attr.password
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.acclivousbyte.gobblecustomer.view.dialog.AlertMessageDialog
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.OnFailureListener
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.extensions.isOnline
import kotlinx.android.synthetic.main.fragment_sign_up.*
import java.lang.Exception


/**
 * A simple [Fragment] subclass.
 */
class SignUpFragment : BaseFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_sign_up, container, false)

        view.findViewById<Button>(R.id.btnRegister).setOnClickListener {
            if (etUserName.text.isNullOrEmpty()) {
                etUserName.error = "Please enter your user name"
                etUserName.requestFocus()
            } else if (!isValidEmail(etEmailAddress.text.toString())) {
                etEmailAddress.error = "Please enter your email address"
                etEmailAddress.requestFocus()
            } else if (etPassword.text.isNullOrEmpty() || etPassword.text.length < 6) {
                etPassword.error = "Please enter valid minimum 6 digit password"
                etPassword.requestFocus()
            } else if (etMobileNumber.text.isNullOrEmpty()) {
                etMobileNumber.error = "Please enter your mobile number"
                etMobileNumber.requestFocus()
            } else {

                if (isOnline(requireContext())) {
                    showProgress1Dialog(true)

                    mAuth.createUserWithEmailAndPassword(etEmailAddress.text.toString(), etPassword.text.toString())
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                db.collection("Users").whereEqualTo("Email", etEmailAddress.text.toString())
                                    .get()
                                    .addOnCompleteListener(
                                        OnCompleteListener {
                                            if (it.isSuccessful) {

                                                Log.d("result1234 ", it.result?.documents.toString())
                                                if (it.result?.documents?.size != 0) {
                                                    showProgress1Dialog(false)
                                                    etEmailAddress.error =
                                                        "That email is already taken. Try another."
                                                    return@OnCompleteListener
                                                } else {
                                                    val user = hashMapOf(
                                                        "User Name" to etUserName.text.toString(),
                                                        "Email" to etEmailAddress.text.toString(),
                                                        "Password" to etPassword.text.toString(),
                                                        "UserId" to mAuth.currentUser!!.uid,
                                                        "Phone Number" to etMobileNumber.text.toString(),
                                                        "status" to "unblock"
                                                    )

                                                    db.collection("Users").document().set(user)
                                                        .addOnCompleteListener(
                                                            OnCompleteListener {
                                                                if (it.isSuccessful) {
                                                                    showProgress1Dialog(false)
                                                                    activity?.onBackPressed()
                                                                    Toast.makeText(
                                                                        context,
                                                                        "User Created",
                                                                        Toast.LENGTH_LONG
                                                                    ).show()
                                                                } else {
                                                                    showProgress1Dialog(false)
                                                                    Toast.makeText(
                                                                        context,
                                                                        it.exception?.message,
                                                                        Toast.LENGTH_LONG
                                                                    )
                                                                        .show()

                                                                }
                                                            })

                                                }

                                            }

                                        }

                                    )

                            }
                        }.addOnFailureListener(object : OnFailureListener{
                            override fun onFailure(p0: Exception) {
                                showProgress1Dialog(false)
                                Log.d("authException", p0.message)
                            }

                        })


                }else{
                    showProgress1Dialog(false)

                    val popUp = AlertMessageDialog.newInstance("Please check your internet connection!")
                    popUp.show(childFragmentManager, "")

                }

            }
        }

        view.findViewById<RelativeLayout>(R.id.already_account_layout).setOnClickListener {
            replaceFragment(SignInFragment(), false, 2)
        }
        return view
    }

}
