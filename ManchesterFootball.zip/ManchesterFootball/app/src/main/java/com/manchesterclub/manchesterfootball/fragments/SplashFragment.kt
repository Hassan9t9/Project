package com.manchesterclub.manchesterfootball.fragments

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.manchesterclub.manchesterfootball.R
import com.nabinbhandari.android.permissions.PermissionHandler
import com.nabinbhandari.android.permissions.Permissions

/**
 * A simple [Fragment] subclass.
 */
class SplashFragment : BaseFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_splash, container, false)
        permissions()
        return view
    }

    fun permissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {

        } else {
            val permissions = arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            Permissions.check(context, permissions, null, null, object : PermissionHandler() {
                override fun onGranted() {
                    if (sessionManager.getLoginString().equals("")) {

                        Handler().postDelayed({
                            replaceFragment(SignInFragment(), false, 0)
                        }, 3000)

                    } else {
                        Handler().postDelayed({
                            replaceFragment(HomeFragment(), false, 0)
                        }, 3000)
                    }
                }

                override fun onDenied(
                    context: Context?,
                    deniedPermissions: java.util.ArrayList<String>?
                ) {
                    super.onDenied(context, deniedPermissions)
                    activity?.finish()
                }
            })
        }

    }
}
