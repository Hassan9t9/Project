package com.manchesterclub.manchesterfootball.fragments

import android.app.ProgressDialog
import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.utils.DialogUtils
import com.manchesterclub.manchesterfootball.utils.FragmentUtil
import com.manchesterclub.manchesterfootball.utils.SessionManager

open class BaseFragment : Fragment() {

    lateinit var sessionManager : SessionManager
    protected var progressDialog: ProgressDialog? = null
    lateinit var dialog: AlertDialog


    lateinit var  db: FirebaseFirestore
    lateinit var mAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = FirebaseFirestore.getInstance()
        mAuth = FirebaseAuth.getInstance()
        sessionManager = SessionManager(requireContext())
        dialog = DialogUtils.getProgressDialog(requireContext())

    }

    protected fun showProgressDialog(message: String) {
        if (progressDialog == null) {
            progressDialog = ProgressDialog(context)
        }

        if (!progressDialog!!.isShowing()) {
            progressDialog = ProgressDialog(context)
            progressDialog!!.setMessage(message)
            progressDialog!!.show()
        }
    }

    public fun isValidEmail(email: String): Boolean {
        val pattern = Patterns.EMAIL_ADDRESS
        return pattern.matcher(email).matches()
    }


    protected fun dismissDialog(){
        progressDialog!!.dismiss()
    }

    fun showProgress1Dialog(show: Boolean) {

        if (dialog != null && show) {
            if (!dialog.isShowing)
                dialog.apply {
                    show()
                }
        } else if (dialog != null && !show) {
            if (dialog.isShowing)
                dialog.dismiss()
        }
    }


    fun addFragment(fragment: Fragment, addToBackStack: Boolean, animationType: Int) {

        FragmentUtil.addFragment(
            activity as AppCompatActivity,
            fragment,
            R.id.fragment_container,
            addToBackStack,
            animationType
        )
    }

    fun replaceFragment(fragment: Fragment, addToBackStack: Boolean, animationType: Int) {

        FragmentUtil.replaceFragment(
            activity as AppCompatActivity,
            fragment,
            R.id.fragment_container,
            addToBackStack,
            animationType
        )
    }

}