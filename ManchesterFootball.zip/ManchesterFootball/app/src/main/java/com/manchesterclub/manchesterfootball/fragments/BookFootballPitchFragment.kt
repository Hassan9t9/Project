package com.manchesterclub.manchesterfootball.fragments

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.DatePicker
import androidx.recyclerview.widget.LinearLayoutManager
import com.acclivousbyte.gobblecustomer.view.dialog.AlertMessageDialog
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.QuerySnapshot
import com.jaiselrahman.hintspinner.HintSpinnerAdapter

import com.manchesterclub.manchesterfootball.R
import com.manchesterclub.manchesterfootball.adapters.BookingPitchAdapter
import com.manchesterclub.manchesterfootball.dialog.DeleteDialog
import com.manchesterclub.manchesterfootball.extensions.isOnline
import com.manchesterclub.manchesterfootball.models.BookingModel
import com.manchesterclub.manchesterfootball.models.FootballPitchModel
import kotlinx.android.synthetic.main.fragment_book_football_pitch.*
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
class BookFootballPitchFragment : BaseFragment(), BookingPitchAdapter.ItemClickListener,
    DeleteDialog.ActionListener, DatePickerDialog.OnDateSetListener  {

    lateinit var footballPitchModel: FootballPitchModel
    val footballPitchList: MutableList<FootballPitchModel> = mutableListOf()
    var selectedFilterTime = ""
    var bookingPitchAdapter: BookingPitchAdapter? = null
    var deleteDialog: DeleteDialog? = null
    var selectedDate = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_book_football_pitch, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        ivBackScreen.setOnClickListener {
            activity?.onBackPressed()
        }


        val selectedTimeArray = ArrayList<String>()

        selectedTimeArray.add("1PM to 2PM")
        selectedTimeArray.add("2PM to 3PM")
        selectedTimeArray.add("3PM to 4PM")
        selectedTimeArray.add("4PM to 5PM")
        selectedTimeArray.add("5PM to 6PM")
        selectedTimeArray.add("6PM to 7PM")
        selectedTimeArray.add("7PM to 8PM")
        selectedTimeArray.add("8PM to 9PM")
        selectedTimeArray.add("9PM to 10PM")
        selectedTimeArray.add("10PM to 11PM")
        selectedTimeArray.add("11PM to 12PM")

        search_by_time.setAdapter(
            HintSpinnerAdapter<String>(
                requireContext(),
                selectedTimeArray,
                "Search by time"
            )
        )

        clear_search.setOnClickListener {
            selected_date.text = ""
            selectedDate = ""
            selectedFilterTime = ""
            val filterChars = "$selectedFilterTime,$selectedDate"
            search_by_time.setAdapter(
                HintSpinnerAdapter<String>(
                    requireContext(),
                    selectedTimeArray,
                    "Search by time"
                )
            )
            bookingPitchAdapter?.filter?.filter(filterChars)
        }

        selected_date.setOnClickListener {
            if (selectedFilterTime.isNotEmpty()) {
                val dialog = DatePickerDialog(
                    requireContext(),
                    this,
                    Calendar.YEAR,
                    Calendar.MONTH,
                    Calendar.DAY_OF_MONTH
                )
                dialog.datePicker.setMinDate(Calendar.getInstance().timeInMillis)

                dialog.show()
            }else{
                selected_date.error = "Please select time first"
            }
        }


        selectedTime()

        showProgress1Dialog(true)

        if (isOnline(requireContext())) {
            db.collection("Football Pitches").get()
                .addOnCompleteListener(object : OnCompleteListener<QuerySnapshot> {
                    override fun onComplete(p0: Task<QuerySnapshot>) {
                        if (p0.isSuccessful) {
                            footballPitchList.clear()
                            for (i in p0.result?.documents!!) {

                                footballPitchModel = FootballPitchModel(
                                    i.getString("pitchId").toString(),
                                    i.getString("nameOfPitch").toString(),
                                    i.getString("locationName").toString(),
                                    i.getString("typesOfPitches").toString(),
                                    i.getString("changeRoom").toString(),
                                    i.getString("onSiteParking").toString(),
                                    i.getString("indoorTxt").toString(),
                                    i.getString("floodLitTxt").toString(),
                                    i.get("selectedTime") as ArrayList<String?>,
                                    i.getString("selectedDate").toString(),
                                    i.getString("visibility").toString()
                                )

                                if (footballPitchModel.visibilty.equals("true")) {
                                    footballPitchList.add(footballPitchModel)
                                }

                            }

                            setAdapter(footballPitchList)
                            showProgress1Dialog(false)
                        }
                    }

                }).addOnFailureListener {
                    val popUp = AlertMessageDialog.newInstance(it.message.toString())
                    popUp.show(childFragmentManager, "")
                }
        } else {
            val popUp = AlertMessageDialog.newInstance("Please check your internet connection")
            popUp.show(childFragmentManager, "")
        }

    }

    fun setAdapter(footballPitchList: MutableList<FootballPitchModel>) {
        bookingPitchAdapter = BookingPitchAdapter(requireContext(), footballPitchList, this)

        rv_football_pitch_list.let {
            it.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            it.adapter = bookingPitchAdapter
        }
    }

    override fun openDetail(notify: FootballPitchModel) {
        replaceFragment(PostPitchFragment.newInstance(notify, true), true, 2)
    }

    override fun deleteBooking(notify: FootballPitchModel) {
        deleteDialog = DeleteDialog(notify, null,this)
        deleteDialog?.show(childFragmentManager, "")
    }

    private fun selectedTime() {

        search_by_time.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val ss = parent?.getItemAtPosition(position)
                selectedFilterTime = ss.toString()

            }

        })

    }

    override fun onClickYes(footballPitchModel: FootballPitchModel?, bookingModel: BookingModel?) {

        deleteDialog?.dismiss()
        showProgress1Dialog(true)
        val hashMap = hashMapOf(
            "visibility" to "false"
        )
        footballPitchModel?.pitchId?.let {
            db.collection("Football Pitches").document(it)
                .update(hashMap as Map<String, Any>).addOnCompleteListener {

                    if (it.isSuccessful) {
                        db.collection("Football Pitches").get()
                            .addOnCompleteListener(object : OnCompleteListener<QuerySnapshot> {
                                override fun onComplete(p0: Task<QuerySnapshot>) {
                                    if (p0.isSuccessful) {
                                        footballPitchList.clear()
                                        for (i in p0.result?.documents!!) {

                                            val mFootballPitchModel = FootballPitchModel(
                                                i.getString("pitchId").toString(),
                                                i.getString("nameOfPitch").toString(),
                                                i.getString("locationName").toString(),
                                                i.getString("typesOfPitches").toString(),
                                                i.getString("changeRoom").toString(),
                                                i.getString("onSiteParking").toString(),
                                                i.getString("indoorTxt").toString(),
                                                i.getString("floodLitTxt").toString(),
                                                i.get("selectedTime") as ArrayList<String?>,
                                                i.getString("selectedDate").toString(),
                                                i.getString("visibility").toString()
                                            )

                                            if (mFootballPitchModel.visibilty.equals("true")) {
                                                footballPitchList.add(mFootballPitchModel)
                                            }

                                        }

                                        setAdapter(footballPitchList)
                                        showProgress1Dialog(false)
                                    }
                                }

                            }).addOnFailureListener {
                                showProgress1Dialog(false)
                                val popUp = AlertMessageDialog.newInstance(it.message.toString())
                                popUp.show(childFragmentManager, "")
                            }
                    }
            }
        }
    }

    override fun onClickNo() {
        deleteDialog?.dismiss()
    }

    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        val getMonth = month+1
        val cal= Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month)
        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

        var monthConverted = ""+getMonth;

        if(getMonth<10){
            monthConverted = "0"+monthConverted;

        }

        selectedDate = ""+year+"-"+ monthConverted +"-"+dayOfMonth

        selected_date.setText(selectedDate)

        val filterChars = selectedFilterTime + "," + selectedDate
        bookingPitchAdapter?.filter?.filter(filterChars)

    }

}
