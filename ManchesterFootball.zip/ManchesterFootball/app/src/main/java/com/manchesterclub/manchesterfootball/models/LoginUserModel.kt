package com.manchesterclub.manchesterfootball.models

class LoginUserModel(
    val userId: String?,
    val email: String?,
    val password: String?,
    val phoneNumber: String?,
    val userName: String?,
    val status: String?,
    var admin: String? = ""
)